<?php

if ($hassiteconfig) { // needs this condition or there is error on login page

    $ADMIN->add('localplugins', new admin_category('local_postmansms_category', get_string('pluginname', 'local_postmansms')));

    $settings = new admin_settingpage('local_postmansms', get_string('pluginname', 'local_postmansms'));
    $ADMIN->add('local_postmansms_category', $settings);

    $settings->add(new admin_setting_configcheckbox('local_postmansms/enabled',
        get_string('setting_enable', 'local_postmansms'), get_string('setting_enable_desc', 'local_postmansms'), '1'));

    $ADMIN->add('local_postmansms_category', new admin_externalpage('local_postmansms_manage', get_string('manage', 'local_postmansms'),
        $CFG->wwwroot . '/local/postmansms/manage.php'));
}
