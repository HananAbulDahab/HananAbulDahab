<?php

/**
 * @package     local_postmansms
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

global $DB;

require_login();
$context = context_system::instance();

require_capability('local/postmansms:managepostmansms', $context);

$PAGE->set_url(new moodle_url('/local/postmansms/manage.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title(get_string('manage_postmansms', 'local_postmansms'));
$PAGE->set_heading(get_string('manage_postmansms', 'local_postmansms'));
$PAGE->requires->js_call_amd('local_postmansms/confirm');
$PAGE->requires->css('/local/postmansms/styles.css');

$gencourses = $DB->get_records('course', null, 'id');

echo $OUTPUT->header();
$templatecontext = (object)[
    'postmansms' => array_values($gencourses),
    'editurl' => new moodle_url('/local/postmansms/editpostmansms.php'),
    
];

echo $OUTPUT->render_from_template('local_postmansms/manage', $templatecontext);

echo $OUTPUT->footer();
