<?php

/**
 * @package     local_genseatno
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

global $DB;

require_login();
$context = context_system::instance();

require_capability('local/genseatno:managegenseatno', $context);

$PAGE->set_url(new moodle_url('/local/genseatno/manage.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title(get_string('manage_genseatno', 'local_genseatno'));
$PAGE->set_heading(get_string('manage_genseatno', 'local_genseatno'));
$PAGE->requires->js_call_amd('local_genseatno/confirm');
$PAGE->requires->css('/local/genseatno/styles.css');

$gencourses = $DB->get_records('course', null, 'id');

echo $OUTPUT->header();
$templatecontext = (object)[
    'genseatno' => array_values($gencourses),
    'editurl' => new moodle_url('/local/genseatno/editgenseatno.php'),
    
];

echo $OUTPUT->render_from_template('local_genseatno/manage', $templatecontext);

echo $OUTPUT->footer();
