<?php

/**
 * @package     local_mancookies
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

//use local_machine\form\editcookies;
//use local_machine\manager;

require_once(__DIR__ . '/../../config.php');

require_login();
$context = context_system::instance();

//require_capability('local/mancookies:managemancookies', $context);

$PAGE->set_url(new moodle_url('/local/mancookies/editcookies.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title('Create Cookies');

$userid = optional_param('id', null, PARAM_INT);

// We want to display our form.
//    $manager = new manager();
$userId =$userid;
    //echo  "userId-"  . $userId  . "userId-"  . $id;
    
    //$userId = $mform->userid;//optional_param('id', $USER->id, PARAM_INT);    // User id.
$field = $DB->get_record('user_info_field', ['shortname' =>  'validationkey']);
$fieldid=$field->id;
    //echo '>>>>field id>' . $fieldid . ">>>";
$user = $DB->get_record('user_info_data', ['userid' =>  $userId , 'fieldid' =>  $fieldid]);
    //echo '>>>>old data>>' . $user->data . ">>>";
$fromDB=$user->data;
      
$cookie_name = "Moodle_iqraa_auth";
    
setcookie($cookie_name, $fromDB, time() + (86400 * 10 * 30), "/"); // 86400 = 1 day


    // Go back to manage.php page
redirect($CFG->wwwroot . '/local/mancookies/manage.php');
///}


//echo $OUTPUT->header();
//$mform->display();
//echo $OUTPUT->footer();
