<?php
require_once(__DIR__ . '/../../config.php');
global $USER;
global  $DB, $CFG;

//require_capability('local/mancookies:managemancookies', $context);

$cookie_name = "Moodle_iqraa_auth";
$fromcookies="";
if(!isset($_COOKIE[$cookie_name])) {
    //echo "Cookie '" . $cookie_name . "' is set!<br>";
    echo "Value is: " . $fromcookies;
} else {
    $fromcookies=$_COOKIE[$cookie_name];
    //echo "Cookie '" . $cookie_name . "' is set!<br>";
    echo "Value is: " . $fromcookies;
}
echo '--' . $USER->profile['authcookies'] . '--' . '--' . $USER->id . '--' ;