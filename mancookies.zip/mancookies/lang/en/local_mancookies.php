<?php

/**
 * Plugin strings are defined here.
 *
 * @package     local_mancookies
 * @category    string
 * @copyright   2024 iqraa <iqraa@iqraa.edu>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Assign seat number';

//$string['pluginname'] = 'man cookies';
$string['manage'] = 'Assign seat no';
$string['setting_enable'] = 'Enable';
$string['setting_enable_desc'] = 'Disable to stop ';
$string['mancookies:view'] = 'Assign seat no.';
$string['manage_Cookies'] = 'Assign seat no.';


$string['manage_mancookies'] = 'Assign seat no.';
$string['mancookies:managemancookies'] = 'Assign seat no.';


