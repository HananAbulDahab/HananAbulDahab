<?php
//require_login();
function local_mancookies_after_require_login() {
    global $USER;
    global $DB, $CFG;
    //if (!isloggedin() or isguestuser()) {
        
    //}else{
        /////////////////////
    if (isloggedin() && !isguestuser()) {
        $cookie_name = "Moodle_iqraa_auth";
        $fromcookies="";
        if(!isset($_COOKIE[$cookie_name])) {
        //    echo "Cookie named '" . $cookie_name . "' is not set!";
        } else {
            $fromcookies=$_COOKIE[$cookie_name];
            //    echo "Cookie '" . $cookie_name . "' is set!<br>";
            //    echo "Value is: " . $_COOKIE[$cookie_name];
        }

        //////////////////////
        
        // get logged in user id
        $userId=$USER->id;
        //$userId = 2;//optional_param('id', $USER->id, PARAM_INT);    // User id.
        $field = $DB->get_record('user_info_field', ['shortname' =>  'validationkey']);
        $fieldid=$field->id;
        //echo '>>>>field id>' . $fieldid . ">>>";
        $user = $DB->get_record('user_info_data', ['userid' =>  $userId , 'fieldid' =>  $fieldid]);
        //echo '>>>>old data>>' . $user->data . ">>>";
        $fromDB=$user->data;
        //$user->data = $newdata;
        if($fromDB==$fromcookies){
        //  echo "OKKKK";
            $authcookiesval="OK";
        }else{
            //echo 'NOT OKKKK';
            $authcookiesval="NOTOK";
        }        
        $field = $DB->get_record('user_info_field', ['shortname' =>  'authcookies']);
        $fieldid=$field->id;
        //echo '>>>>field id>' . $fieldid . ">>>";



        $user = $DB->get_record('user_info_data', ['userid' =>  $userId , 'fieldid' =>  $fieldid]);
        //echo '>>>>old data>>' . $user->data . ">>>";

        $user->data = $authcookiesval;
        
        $DB->update_record('user_info_data', $user, $bulk=false);

        remove_dir($CFG->dataroot.'/cache', true);

        //$USER->authcookies=$authcookiesval;
        $USER->profile['authcookies']=$authcookiesval;
        //profile_load_custom_fields($USER);
        // echo "aaa";

        //$DB->update_record('user_info_data', $object);

        //  echo "fff";
   
    }

}